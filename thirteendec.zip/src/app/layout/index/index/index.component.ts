import { Component, OnInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {
  @ViewChild('fullpageRef',{static:false}) fp_directive: ElementRef;
  config;
  fullpage_api;

  constructor(private renderer: Renderer2) { 

    this.config = {
      autoScrolling: true,
      navigation: true,
      navigationPosition: 'right',
      anchors: ['firstPage', 'secondPage', 'thirdPage', 'fourthPage'],
      navigationTooltips: ['Home', 'Who We Are','What We Do', 'Who We Have Helped'],
      fitToSection:true,
      // responsiveHeight:766,
      responsiveSlides:false,
      // scrollBar:true,
      // showActiveTooltip: true,

      // events callback
      afterLoad: (origin, destination, direction) => {
        // console.log(destination);
      },
      afterRender: () => {
        // console.log('afterRender');
      },
      afterResize: (width, height) => {
        // console.log('afterResize' + width + ' ' + height);
      },
      afterSlideLoad: (section, origin, destination, direction) => {
        // console.log(destination);
      },
      afterResponsive: (isResponsive)=>{
        // alert("Is responsive: " + isResponsive);
      }
    };
  }
    //Coding For full page js
    //Coding For full page js ends

  //Coding For OWL-Carosuls
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['<span class="icon-left-open-big">', '<span class="icon-right-open-big">'],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 5
      },
      740: {
        items: 5
      },
      940: {
        items: 5
      }
    },
    nav: true
  }
  //Coding For OWL-Carosuls

  ngOnInit() {
  } 

  // full js
  getRef(fullPageRef) {
    this.fullpage_api = fullPageRef;
    // this.fullpage_api.fitToSection();
    // this.fullpage_api.setFitToSection(true);
    // this.fullpage_api.setResponsive(false);
    // this.fullpage_api.responsiveSlides.toSections();
    // this.fullpage_api.responsiveSlides.toSlides();
  }
  //full js

}

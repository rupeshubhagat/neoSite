import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IndexRoutingModule } from './index-routing.module';
import { HeaderComponent } from './header/header.component';
import { MaterialModule } from 'src/app/shared/material/material.module';



@NgModule({
  declarations: [HeaderComponent],
  imports: [
    CommonModule,
    IndexRoutingModule,
    MaterialModule
  ]
})
export class IndexModule { }
